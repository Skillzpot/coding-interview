/* Pointer assignments program */

#include<stdio.h>

int count_1s(int num) {
  int check_bit = 1;
  int count = 0;
  while (check_bit != 0) {
    if ((num & check_bit) == check_bit) {
      count++;
    }
    check_bit = check_bit << 1;
  }

  return count;
}

int count_1s_optimized(int num) {
  int count = 0;
  while (num != 0) {
    num = num & (num - 1);
    count++;
  }

  return count;
}


int main() {
  printf("There are %d 1s in %d\n", count_1s_optimized(8), 8);
  printf("There are %d 1s in %d\n", count_1s_optimized(31), 31);
  printf("There are %d 1s in %d\n", count_1s_optimized(3), 3);
}
