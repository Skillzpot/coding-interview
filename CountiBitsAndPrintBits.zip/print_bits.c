/* Pointer assignments program */

#include<stdio.h>

void print_bits(int num) {
  unsigned int check_bit = 1 << (sizeof(int) * 8 - 1);
  
  while (check_bit != 0) {
    int result = num & check_bit;
    if (result == check_bit) {
      printf("%d ", 1);
    } else {
      printf("%d ", 0);
    }

    check_bit = check_bit >> 1;
  }

  printf("\n");
}

int main() {
  print_bits(2);
  print_bits(15);
}
